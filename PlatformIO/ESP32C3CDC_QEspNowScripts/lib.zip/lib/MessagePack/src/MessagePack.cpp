#include <Arduino.h>
#include "MessagePack.h"

unsigned char MESSAGE_PACK_LEN[] = {0, 1, 1, 2, 4, 4, 0};