
var x=2
print 1
print x
print x+1
print x*x
print (7-2)
print 1+2+3
x=7
print x
print (-x)+15
print 6+x/2
print x*2-4
print 123%10
print 0x10
print 0x123
print 0xa
print 0xFEED
print 0x12abc
print '0'
print '\n'
print '\''

# now test strings
print "x=", x
print {or we can say it with {}: x+1=}, (x+(x-(x))) + 1

print "now test if statements"
var y=0
print "x=", x, " y=", y
if (y = x) {
  print "x and y are equal"
} else {
  print "x and y differ"
}
if (1) {
  var x=2
  print "x=", x
}
print "now x=", x
